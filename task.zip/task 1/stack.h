#ifndef STACK_H
#define STACK_H

#include <iostream>

using namespace std;

struct SNode {
    long long value; 
    SNode* next;
};

struct Stack {
    SNode* head;
};

void createStack(Stack*& st);
SNode* createSNode(long long data); 
void push(Stack* st, long long data);  
void pop(Stack* st);
void printStack(Stack* st);

#endif // STACK_H