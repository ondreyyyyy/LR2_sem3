#include <iostream>
#include <cstdint>
#include <stdexcept>
#include "stack.h"

using namespace std;

int priority(char operation) {
    if (operation == '+' || operation == '-') return 1;
    if (operation == '*') return 2;
    return 0;
}

bool isEmptyStack(Stack* st) {
    return st->head == nullptr;
}

long long getTopElement(Stack* st) {
    if (isEmptyStack(st)) {
        throw runtime_error("Ошибка: стек пуст.\n");
    }
    return st->head->value;
}

void calculate(Stack* numStack, Stack* opStack) {
    if (isEmptyStack(opStack) || isEmptyStack(numStack) || numStack->head->next == nullptr) {
        throw runtime_error("Неверное выражение!\n"); 
    }

    // получение чисел и операции надо ними

    char operation = (char)getTopElement(opStack);
    pop(opStack);

    long long b = getTopElement(numStack);
    pop(numStack);

    long long a = getTopElement(numStack);
    pop(numStack);

    // вычисление

    long long result;
    switch(operation) {
        case '+': result = a + b; break;
        case '-': result = a - b; break;
        case '*': result = a * b; break;
        default: throw runtime_error("Неизвестная операция!\n");
    }

    // по условию, результат не превышает 2*10^9
    if (result > 2000000000 || result < -2000000000) {
        throw runtime_error("Ошибка. Результат вышел за границу.\n");
    }

    push(numStack, result);
}

bool isNeedCalculate(Stack* opStack, char curOperation) { // гарантия выполнения операций в верном порядке
    if (isEmptyStack(opStack) || (char)getTopElement(opStack) == '(') {
        return false;
    }

    return priority((char)getTopElement(opStack)) >= priority(curOperation);
}

long long evaluateExpression(const string& exp) {
    Stack* numStack = new Stack;
    Stack* opStack = new Stack;
    createStack(numStack);
    createStack(opStack);

    int i = 0;
    int n = exp.length();

    try {
        while (i < n) {
            if (exp[i] == ' ') {
                i++;
                continue;
            }

            if (isdigit(exp[i])) {
                long long num = 0;
                while (i < n && isdigit(exp[i])) {
                    num = num * 10 + (exp[i] - '0');
                    i++;

                    if (num > 2000000000) {
                        throw runtime_error("Результат слишком большой.\n");
                    }
                }

                push(numStack, num);
                continue;
            }

            if (exp[i] == '(') {
                push(opStack, (long long)'(');
            }
            else if (exp[i] == ')') {
                while (!isEmptyStack(opStack) && (char)getTopElement(opStack) != '(') {
                    calculate(numStack, opStack);
                }
                if (isEmptyStack(opStack)) {
                    throw runtime_error("Скобки непарные.\n");
                }
                pop(opStack);
            }
            else if (exp[i] == '+' || exp[i] == '-' || exp[i] == '*') {
                while (!isEmptyStack(opStack) && isNeedCalculate(opStack, exp[i])) {
                    calculate(numStack, opStack);
                }
                push(opStack, (long long)exp[i]);
            }
            else {
                throw runtime_error("Неизвестная операция.\n");
            }

            i++;
        }

        while (!isEmptyStack(opStack)) { // нет скобки парной, затем вычисление операций, приоритет которых не важен
            if ((char)getTopElement(opStack) == '(') {
                throw runtime_error("Неверная запись.\n");
            }

            calculate(numStack, opStack);
        }

        if (isEmptyStack(numStack)) { // нет результата
            throw runtime_error("Ошибка выражения.\n");
        }

        long long result = getTopElement(numStack);
        pop(numStack);

        if (!isEmptyStack(numStack)) { // лишние числа после результата
            throw runtime_error("Неверное выражение.\n");
        }

        while (!isEmptyStack(numStack)) pop(numStack);
        while (!isEmptyStack(opStack)) pop(opStack);
        delete numStack;
        delete opStack;
        
        return result;
    }
    catch (...) {
        while (!isEmptyStack(numStack)) pop(numStack);
        while (!isEmptyStack(opStack)) pop(opStack);
        delete numStack;
        delete opStack;
        throw;
    }
}

int main() {
    char choice = 'y';
    
    while (choice == 'y' || choice == 'Y') {
        cout << "Введите арифметическое выражение: ";
        string expression;
        getline(cin, expression);
        
        try {
            long long result = evaluateExpression(expression);
            cout << "Результат: " << result << endl;
        } catch (const exception& e) {
            cout << "Ошибка: " << e.what();
        }
        
        cout << "Продолжить? (y/n): ";
        cin >> choice;
        cin.ignore();
    }
    
    cout << "Работы программы завершена." << endl;
    return 0;
}